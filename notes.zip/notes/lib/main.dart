import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Заметки',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.teal,
        useMaterial3: true,
      ),
      home: const NotesPage(),
    );
  }
}

class NotesPage extends StatefulWidget {
  const NotesPage({super.key});

  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final TextEditingController controller = TextEditingController();
  List<String> notes = [];
  int editIndex = -1;

  void saveNote() {
    String text = controller.text.trim();
    if (text.isEmpty) {
      return;
    }
    setState(() {
      if (editIndex == -1) {
        notes.add(text);
      } else {
        notes[editIndex] = text;
        editIndex = -1;
      }
      controller.clear();
    });
  }

  void startEdit(int index) {
    setState(() {
      editIndex = index;
      controller.text = notes[index];
    });
  }

  void cancelEdit() {
    setState(() {
      editIndex = -1;
      controller.clear();
    });
  }

  void deleteNote(int index) {
    setState(() {
      notes.removeAt(index);
      if (editIndex >= 0) {
        editIndex = -1;
        controller.clear();
      }
    });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Заметки'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: controller,
              maxLines: 3,
              minLines: 1,
              decoration: InputDecoration(
                labelText: editIndex == -1 ? 'Новая заметка' : 'Редактирование заметки',
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: saveNote,
                    child: Text(editIndex == -1 ? 'Сохранить' : 'Сохранить изменения'),
                  ),
                ),
                if (editIndex >= 0) const SizedBox(width: 10),
                if (editIndex >= 0)
                  TextButton(
                    onPressed: cancelEdit,
                    child: const Text('Отмена'),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: notes.isEmpty
                  ? const Center(
                      child: Text(
                        'Заметок пока нет',
                        style: TextStyle(color: Colors.grey, fontSize: 16),
                      ),
                    )
                  : ListView.builder(
                      itemCount: notes.length,
                      itemBuilder: (context, index) {
                        return Card(
                          color: editIndex == index ? Colors.teal.shade50 : null,
                          child: ListTile(
                            leading: CircleAvatar(
                              child: Text('${index + 1}'),
                            ),
                            title: Text(notes[index]),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Colors.blue),
                                  onPressed: () => startEdit(index),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () => deleteNote(index),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
